const Koa = require('koa');
const Router = require('koa-router');
const fs = require('fs');
const path = require('path');
const config = require('./config');
var cors = require('koa2-cors');

const koaBody = require('koa-body');
const staticFile = require('koa-static');
const send = require('koa-send');

const router = new Router();
const app = new Koa();
const {uuid} = require("./utils")
app.use(cors({
  methods:['GET', 'PUT', 'POST']
}));
app.use(koaBody({
  multipart: true,
  formidable: {
      maxFileSize: 200*1024*1024    // 设置上传文件大小最大限制，默认2M
  }
}));

var MongoClient = require('mongodb').MongoClient;
var dbUrl = 'mongodb://127.0.0.1:27017';
var dbName = 'soldier';

// var dbUrl = 'mongodb+srv://zhiyue:admin@cluster0.rrniu.mongodb.net?retryWrites=true&w=majority';
// var dbUrl = 'mongodb://zhiyue:admin@52.22.69.39:27017?retryWrites=true&w=majority';

// var dbName = 'project1';

// 连接数据库
console.time('start1');
let db;

MongoClient.connect(dbUrl, (err, client) => {
  if (err) {
    console.log(err);
    return;
  }
 
  db = client.db(dbName);
  // 查询数据
  var result = db.collection('soldier').find({});
  result.toArray((err, docs) => {
    console.timeEnd('start1')
    console.log(docs)
  })
})
 
// // 连接数据库
// console.time('start2');
// MongoClient.connect(dbUrl, (err, client) => {
//   if (err) {
//     console.log(err);
//     return;
//   }
 
//   var db = client.db(dbName);
//   // 查询数据
//   var result = db.collection('user').find({});
//   result.toArray((err, docs) => {
//     console.timeEnd('start2')
//     console.log(docs)
//   })
// })


function responseSuccess(data){
  return {
    meta:{
      errno:0,
      msg:"保存成功"
    },
    result:data
  }
}
router.post('/uploadfile', async (ctx, next) => {
  // 上传单个文件
  const file = ctx.request.files.file; // 获取上传文件
  // 创建可读流
  const reader = fs.createReadStream(file.path);
  let filePath= 'static/'+uuid();
  // 创建可写流
  const upStream = fs.createWriteStream(path.join(__dirname, filePath));
  // 可读流通过管道写入可写流
  reader.pipe(upStream);
  return ctx.body = filePath;
});

router.get('/file', async (ctx) => {
  const id = ctx.query.id;
  const path = 'static/'+uuid();
  ctx.attachment(path);
  await send(ctx, path);
});

router.post('/list', async (ctx) => {
   // 查询数据
   let {
    name,
    offset
  } = ctx.request.body;

  let pageSize = 10;
  
   console.log("list================");
   var result = db.collection('soldier').find(name?{name:name}:{});
   
   let list = await new Promise((resolve,reject)=>{
    result.toArray((err, docs) => {
      resolve(docs);
      console.log(docs)
    })
   })

   await listDeal(list);
   offset = offset || 0
   list = list.slice(offset,offset+pageSize)
   
   ctx.body = responseSuccess(list);
});

// 将list转为树
function getItem(oldArr,id){
  return newArr.find(element => element.id===id)
}

// 将list转为树
function listToTree(oldArr){
  let newArr = [...oldArr];
  newArr.forEach(element => {
    let superior = element.superior;
    if(superior !== 0){
      newArr.forEach(ele => {
        if(ele.id == superior){ //当内层循环的ID== 外层循环的parendId时，（说明有children），需要往该内层id里建个children并push对应的数组；
          if(!ele.children){
            ele.children = [];
          }
          ele.children.push(element);
        }
      });
    }
  });
  console.log(newArr) //此时的数组是在原基础上补充了children;
  newArr = newArr.filter(ele => ele.superior === 0); //这一步是过滤，按树展开，将多余的数组剔除；
  console.log(newArr)
  return newArr;
}


router.post('/getChildrenList', async (ctx) => {
  // 查询数据 自己不能选择自己的下级
  const {
   id
 } = ctx.request.body;
 
  console.log("list================");
  var result = db.collection('soldier').find({superior:id});
  
  let list = await new Promise((resolve,reject)=>{
   result.toArray((err, docs) => {
     resolve(docs);
     console.log(docs)
   })
  })
  
  await listDeal(list);

  ctx.body = responseSuccess(list);
});




router.post('/listSuper', async (ctx) => {
  // 查询数据 自己不能选择自己的下级
  const {
   id
 } = ctx.request.body;
 
  console.log("list================");
  var result = db.collection('soldier').find({});
  
  let list = await new Promise((resolve,reject)=>{
   result.toArray((err, docs) => {
     resolve(docs);
     console.log(docs)
   })
  })
  if(id){
    for(let i=0;i<list.length;i++){
      let item = list[i];
      if(item.superior===id || item.id ===id ){
        list.splice(i,1);
        i--;
      }
    }
  }
  await listDeal(list);
  ctx.body = responseSuccess(list);
});

async function listDeal(arr){
  var result = db.collection('soldier').find({});
   
  let list = await new Promise((resolve,reject)=>{
    result.toArray((err, docs) => {
      resolve(docs);
      console.log(docs)
    })
  })

  let newList = listToTree(list);
  arr.forEach((item)=>{
      let find = list.find((item2)=>item2.id===item.id)
      item.subordinates = find.children ? find.children.length:0
      if(find){
        item.superiorName = find.name
      }
      delete item.children 
  })
}



router.post('/savePet', async (ctx) => {
  console.log("ctx.request.body",ctx.request.body);

  const {
    avatar,
    name,
    classify,
    sex,
    birthday,
    master,
    masterphone
  } = ctx.request.body;
  
  let obj = {
    avatar,
    name,
    classify,
    sex,
    birthday,
    master,
    masterphone,
    id:uuid()
  }
  var result = db.collection('soldier').insert(obj);
  ctx.body = {
    meta:{
      errno:0,
      msg:"保存成功"
    },
    result:null
  };
});


router.post('/updatePet', async (ctx) => {
  const {
    avatar,
    name,
    classify,
    sex,
    birthday,
    master,
    masterphone,
    id
  } = ctx.request.body;
  
  let obj = {
    avatar,
    name,
    classify,
    sex,
    birthday,
    master,
    masterphone,
    avatar
  }
  var result = db.collection('soldier').update({
    id:id
  },{$set:obj});
  ctx.body = responseSuccess(null);
})


router.post('/removePet', async (ctx) => {
  const {
    id,
    superior
  } = ctx.request.body;
  // 重新设置父级
  var result = db.collection('soldier').find({});
  let list = await new Promise((resolve,reject)=>{
    result.toArray((err, docs) => {
      resolve(docs);
      console.log(docs)
    })
  })

  if(superior){
    let promises = [];
    list.forEach((item)=>{
      if(item.superior===id){
        item.superior = superior
        promises.push(new Promise((resolve,reject)=>{
          let r = db.collection('soldier').update({
            id:item.id
          },{$set:item});
          resolve(r);
        }))
      }
    })
    await Promise.all(promises)
  }
  

  db.collection('soldier').remove({id:id});

  
  ctx.body = responseSuccess(null);
})


router.get('/unit-test', async (ctx) => {
  console.log("unit-test");
  ctx.body = responseSuccess(null);
})


app.use(staticFile(path.join(__dirname)));

app.use(router.routes());

app.listen(32324)
console.log('app started at port 32324...')
