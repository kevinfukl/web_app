 
 mongdb启动命令 
 sudo ./mongod --dbpath ~/Documents/data/mongodb --logpath ~/Documents/data/mongodb/mongo11

 如果没有出现光标闪烁的界面 说明没有成功,查看~/Documents/data/mongodb/mongo11 的日志说明,一行行找找看看什么问题
