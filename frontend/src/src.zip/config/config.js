import defaultSettings from './defaultSettings';

let prefix = "http://localhost:5005"
export default {
  prefix:prefix
};
