import { get,post,put } from '../http/api'
// 获取图书列表
export const getList = async (params) => {
  return get('/listings',params)
}
export const getDetail = async (params) => {
  return get('/listings/'+params.id,params)
}

export const listSuper = async (params) => {
  return post('/listSuper',params)
}

// save Pet
export const saveObj = async (params) => {
  return post('/listings/new',params)
}

// update Pet
export const updateObj = async (params) => {
  return put('/listings/'+params.id,params)
}

// update Pet
export const publish = async (params) => {
  return put('/listings/publish/'+params.id,params)
}
export const book = async (params) => {
  return post('/bookings/new/'+params.id,params)
}

// remove Pet
export const removeObj = async (params) => {
  return post('/removePet',params)
}
export const getChildrenList = async (params) => {
  return post('/getChildrenList',params)
}

export const register = async (params) => {
  return post('/user/auth/register',params)
}

export const login = async (params) => {
  return post('/user/auth/login',params)
}




