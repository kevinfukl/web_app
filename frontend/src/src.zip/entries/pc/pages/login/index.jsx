/**
 * 士兵页面
 *
 *
 */
import React, { memo, useState, useEffect } from 'react';
import { message } from 'antd';

import './index.scss';
import { login} from '../../../../api/pet'

class ListData extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      email:"",
      password:""
    };
  }

  async submit(){
    const {email,password} = this.state;
    let res = await login({
      email,
      password
    });
    console.log("res=",res);
    if(res.error){
      message.error(res.error);
    }else{
      localStorage.setItem("token","Bearer "+res.token);
      localStorage.setItem("user",JSON.stringify({
        email,
        password
      }))
      this.props.history.push("/")
    }
  }

  render() {
    const {email,password} = this.state;

    return (
      <div class="container">
        <div class="container-wrapper">
          <div class="caption">Hello,</div>
          <div class="caption">
            <text>Welcome</text>
            <div class="hello">hello</div>
          </div>
          <div class="email">
            <input class="email-input" placeholder="Input Email" value={email} onChange={(event)=>{
              this.setState({
                email:event.target.value
              })
            }} />
          </div>
          <div class="password">
            <input class="password-input" placeholder="Input Password" value={password} onChange={(event)=>{
              this.setState({
                password:event.target.value
              })
            }}  />
          </div>
          <div class="login-button" click="confirm" onClick={()=>{
            this.submit();
          }}>Login</div>
          <div class="tail">
            <div class="right" onClick={()=>{
              console.log("register==",this.props)
              this.props.history.push("/register")
            }}>Register</div>
          </div>
        </div>
      </div>);
  }
};

export default ListData;
