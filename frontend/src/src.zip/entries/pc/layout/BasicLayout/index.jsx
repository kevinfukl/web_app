import React from 'react';
import './index.scss';

export default function BasicLayout(params= {children:{}}) {
  return (
    <section className='basic-layout'>
      {params.children}
    </section>
  );
}
